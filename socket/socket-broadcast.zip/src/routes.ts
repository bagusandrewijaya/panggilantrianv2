import { Router, Request, Response } from "express";

const router = Router();


router.get("/", (req: Request, res: Response) => {
  res.json({ message: "API is running 🚀" });
});

router.post("/broadcast", (req: Request, res: Response) => {
  const { message } = req.body || {}; // ✅ aman jika req.body undefined

  if (!message) {
    return res.status(400).json({ success: false, error: "Missing message" });
  }

  req.io.emit("broadcast", { message });
  res.json({ success: true, message });
});

router.post("/tocounter", (req: Request, res: Response) => {
  const { counter, message } = req.body || {}; // ✅ aman juga di sini

  if (!message || !counter) {
    return res
      .status(400)
      .json({ success: false, error: "Missing message or room" });
  }

  req.io.to(counter).emit("broadcast", { message });
  res.json({ success: true, sentTo: counter, message });
});

export default router;
