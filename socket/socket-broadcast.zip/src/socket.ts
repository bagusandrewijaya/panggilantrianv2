import { Server, Socket } from "socket.io";

export function registerSocketHandlers(io: Server, socket: Socket) {
  socket.on("chat message", (msg: string) => {
    console.log(`💬 Message: ${msg}`);
    io.emit("chat message", msg);
  });

  socket.on("disconnect", () => {
    console.log(`❌ Client disconnected: ${socket.id}`);
  });
}
