import express, { Request, Response, NextFunction } from "express";
import http from "http";
import { Server as SocketIOServer } from "socket.io";
import dotenv from "dotenv";
import { registerSocketHandlers } from "./socket";
import router from "./routes";


dotenv.config();

const app = express();
app.use(express.json()); 
app.use(express.urlencoded({ extended: true }));
const server = http.createServer(app);
const io = new SocketIOServer(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"],
  },
});

declare global {
  namespace Express {
    interface Request {
      io: SocketIOServer;
    }
  }
}

app.use((req: Request, res: Response, next: NextFunction) => {
  req.io = io;
  next();
});

app.use(express.json());

app.use((req: Request, res: Response, next: NextFunction) => {
  const headerKey = req.header("X-HEADER-KEY");
  const validKey = process.env.HEADER_KEY;

 if (headerKey !== validKey) {
      return res.status(401).json({
        status: 401,
        message: "Unauthorized: Invalid key",
      });
    }

  next();
});

app.use("/api", router);

io.on("connection", (socket) => {
  console.log(`🔌 Client connected: ${socket.id}`);

  socket.on("joincounter", (array: any) => {
    const roomName = `${array.nocounter}`;
    socket.join(roomName);
    console.log(`📦 ${socket.id} joined room: ${roomName}`);
  });

  // registerSocketHandlers(io, socket);
});

const PORT = 3000;
server.listen(PORT, () => console.log(`✅ Server running on port ${PORT}`));
